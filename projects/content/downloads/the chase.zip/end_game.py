import tkinter as tk
import pygame

pygame.mixer.init()
lose_sound = pygame.mixer.Sound('audio/game_lose.mp3')
win_sound = pygame.mixer.Sound('audio/game_win.mp3')

def show_end_screen(result: str):
    """
    result: either 'win' or 'lose'
    """
    message = {
        "win": "Mate you got this exam, don't sweat 👊",
        "lose": "You lose, revise more idiot 💀"
    }[result]

    sound = {
        "win": win_sound,
        "lose": lose_sound
    }[result]
    sound.play()

    color = "#00cc66" if result == "win" else "#cc0000"

    end_root = tk.Tk()
    end_root.title("Game Over")
    end_root.configure(bg="#1a1a1a")
    end_root.geometry("500x200")

    label = tk.Label(end_root, text=message, font=("Helvetica", 20, "bold"),
                     bg="#1a1a1a", fg=color, wraplength=480)
    label.pack(expand=True)

    btn = tk.Button(end_root, text="Close", font=("Helvetica", 14), command=end_root.destroy,
                    bg="#333", fg="white", padx=10, pady=5)
    btn.pack(pady=10)

    end_root.mainloop()
