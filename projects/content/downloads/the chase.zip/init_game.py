import tkinter as tk
from tkinter import ttk, messagebox
import json
import random
import pygame
from play_game import TheChaseQuizGame

pygame.mixer.init()

intro_music = pygame.mixer.Sound('audio/intro.mp3')

def start_game():
    intro_music.stop()

    selected_paper = paper_var.get()
    selected_difficulty = difficulty_var.get()

    if not selected_paper or not selected_difficulty:
        messagebox.showwarning("Input Missing", "Please select both paper and difficulty.")
        return

    with open("aqa_business_questions.json", "r") as f:
        all_questions = json.load(f)

    # filter questions
    filtered = [
        q for q in all_questions
        if q["paper"].lower() == selected_paper.lower() and q["difficulty"].lower() == selected_difficulty.lower()
    ]

    if not filtered:
        messagebox.showinfo("No Questions", f"No questions found for {selected_paper} - {selected_difficulty}.")
        return

    random.shuffle(filtered)

    # destroy launcher and open game
    launcher.destroy()
    root = tk.Tk()
    app = TheChaseQuizGame(root, filtered)
    root.mainloop()

# launcher window
launcher = tk.Tk()
launcher.title("Launch The Chase")
launcher.configure(bg="#1a1a1a")
launcher.geometry("400x250")

# dropdowns
tk.Label(launcher, text="Select Paper", font=("Helvetica", 14), bg="#1a1a1a", fg="white").pack(pady=(20, 5))
paper_var = tk.StringVar()
paper_dropdown = ttk.Combobox(launcher, textvariable=paper_var, values=["Paper 1", "Paper 2"], state="readonly", font=("Helvetica", 12))
paper_dropdown.pack()

tk.Label(launcher, text="Select Difficulty", font=("Helvetica", 14), bg="#1a1a1a", fg="white").pack(pady=(20, 5))
difficulty_var = tk.StringVar()
difficulty_dropdown = ttk.Combobox(launcher, textvariable=difficulty_var, values=["easy", "medium", "hard"], state="readonly", font=("Helvetica", 12))
difficulty_dropdown.pack()

# start button
tk.Button(launcher, text="Start Game", command=start_game, font=("Helvetica", 14, "bold"), bg="#0066cc", fg="white").pack(pady=30)

intro_music.play()

launcher.mainloop()