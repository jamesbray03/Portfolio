import tkinter as tk
import json
import random
import pygame
from end_game import show_end_screen

# load and shuffle the questions
with open("aqa_business_questions.json", "r") as f:
    questions = json.load(f)

random.shuffle(questions)

pygame.mixer.init()

background_music = pygame.mixer.Sound('audio/background_music.mp3')
background_music.set_volume(0.5)

start_sound = pygame.mixer.Sound('audio/start_game.mp3')
right_answer = pygame.mixer.Sound('audio/right_answer.mp3')
wrong_answer = pygame.mixer.Sound('audio/wrong_answer.mp3')
chaser_answer = pygame.mixer.Sound('audio/chaser_answer.mp3')
question_appear = pygame.mixer.Sound('audio/question_appear.mp3')


class TheChaseQuizGame:
    def __init__(self, root, questions):
        self.root = root
        self.root.title("The Chase: A-Level Business Edition")
        self.root.configure(bg="#1a1a1a")
        self.questions = questions
        self.current_index = 0
        self.player_position = 5
        self.chaser_position = 0

        self.main_frame = tk.Frame(root, bg="#1a1a1a")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self.scoreboard_frame = tk.Frame(self.main_frame, bg="#1a1a1a")
        self.scoreboard_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        self.scoreboard = [tk.Label(self.scoreboard_frame, text="", font=("Helvetica", 12), width=10, fg="white", bg="#333") for _ in range(13)]
        for label in self.scoreboard:
            label.pack(anchor="w", pady=2)

        self.question_frame = tk.Frame(self.main_frame, padx=20, pady=20, bg="#1a1a1a")
        self.question_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.question_label = tk.Label(self.question_frame, text="", wraplength=600, font=("Helvetica", 16), fg="white", bg="#1a1a1a")
        self.question_label.pack(pady=10)

        self.buttons = []
        for i in range(4):
            btn = tk.Button(self.question_frame, text="", width=50, font=("Helvetica", 14), command=lambda i=i: self.check_answer(i), bg="#333", fg="white", disabledforeground="white")
            btn.pack(pady=5)
            self.buttons.append(btn)

        self.update_scoreboard()

        button_frame = tk.Frame(self.question_frame, bg="#1a1a1a")
        button_frame.pack(pady=10)

        self.check_chaser_button = tk.Button(button_frame, text="Check Chaser", font=("Helvetica", 14, "bold"), command=self.check_chaser,state=tk.DISABLED, bg="#0066cc", fg="white")
        self.check_chaser_button.pack(side=tk.LEFT, padx=5)

        self.next_button = tk.Button(button_frame, text="Next Question", font=("Helvetica", 14, "bold"), command=self.next_question, state=tk.DISABLED, bg="#cc0000", fg="white")
        self.next_button.pack(side=tk.LEFT, padx=5)

        self.status_label = tk.Label(self.question_frame, text="", font=("Helvetica", 12), fg="#aaa", bg="#1a1a1a")
        self.status_label.pack(pady=10)

        self.display_question()

        start_sound.play()
        self.root.after(int(start_sound.get_length() * 1000), lambda: background_music.play(-1))

    def display_question(self):
        question_appear.play()
        self.next_button.config(state=tk.DISABLED)
        self.check_chaser_button.config(state=tk.DISABLED)

        self.reset_button_colors()

        q = self.questions[self.current_index].copy()
        self.correct_answer = q["answer"]
        choices = q["choices"].copy()
        random.shuffle(choices)

        self.question_label.config(text=f"Q{self.current_index + 1}: {q['question']}")
        for i, choice in enumerate(choices):
            self.buttons[i].config(text=choice, state=tk.NORMAL)

        self.status_label.config(text=f"Difficulty: {q['difficulty'].capitalize()} | Topic: {q['topic']} | {q['paper']} ({q['year']})")

    def check_answer(self, index):
        selected = self.buttons[index]['text']
        is_correct = selected == self.correct_answer

        for btn in self.buttons:
            btn.config(state=tk.DISABLED)
            if btn['text'] == self.correct_answer:
                btn.config(bg="green")
            elif btn['text'] == selected:
                btn.config(bg="blue")
            
        if is_correct:
            self.player_position += 1
            right_answer.play()
        else:
            wrong_answer.play()

        self.check_chaser_button.config(state=tk.NORMAL)

        if self.player_position >= len(self.scoreboard):
            background_music.stop()
            self.root.destroy()
            show_end_screen("win")

    def update_scoreboard(self):
        for i in range(13):
            if i > self.player_position:
                self.scoreboard[i].config(text="", bg="#00e")
            elif i == self.player_position:
                if i == self.chaser_position:
                    self.scoreboard[i].config(text="busted", bg="#22f")
                else:
                    self.scoreboard[i].config(text="you", bg="#22f")
            elif i == self.chaser_position:
                self.scoreboard[i].config(text="hegarty", bg="#e00")
            elif i < self.chaser_position:
                self.scoreboard[i].config(text="", bg="#f22")
            else:
                self.scoreboard[i].config(text="", bg="#333")

    def next_question(self):
        self.current_index += 1
        if self.current_index < len(self.questions):
            self.display_question()
        else:
            self.question_label.config(text="🎉 You've completed the quiz!")
            for btn in self.buttons:
                btn.pack_forget()
            self.status_label.config(text=f"Final Score: {self.score}/{len(self.questions)}")
            self.next_button.pack_forget()

    def check_chaser(self):
        chaser_answer.play()
        if random.random() < 0.8:
            self.chaser_choice = self.correct_answer
        else:
            incorrect_choices = [choice for choice in self.questions[self.current_index]["choices"] if choice != self.correct_answer]
            self.chaser_choice = random.choice(incorrect_choices)

        if self.chaser_choice == self.correct_answer:
            self.chaser_position += 1

        self.update_scoreboard()

        self.next_button.config(state=tk.NORMAL)
        self.check_chaser_button.config(state=tk.DISABLED)

        for btn in self.buttons:
            if btn['text'] == self.chaser_choice:
                btn.config(bg="red")

        if self.chaser_position >= self.player_position:
            background_music.stop()
            self.root.destroy()
            show_end_screen("lose")

    def reset_button_colors(self):
        for btn in self.buttons:
            btn.config(bg="#333", fg="white")